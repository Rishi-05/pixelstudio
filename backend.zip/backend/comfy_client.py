"""
comfy_client.py
Thin async wrapper around ComfyUI's REST + WebSocket API.
"""
import asyncio
import json
import uuid
from typing import AsyncIterator, Callable

import httpx
import websockets

from core.config import get_settings

settings = get_settings()


# ── Default SDXL workflow template ───────────────────────────────────────────

def build_workflow(
    positive: str,
    negative: str,
    width: int = 512,
    height: int = 512,
    steps: int = 20,
    cfg: float = 7.0,
    sampler: str = "dpmpp_2m",
    seed: int = -1,
    checkpoint: str = "v1-5-pruned-emaonly.safetensors",
) -> dict:
    """Return a ComfyUI-compatible prompt dict (node graph)."""
    if seed == -1:
        import random
        seed = random.randint(0, 2**32 - 1)

    return {
        "4": {
            "class_type": "CheckpointLoaderSimple",
            "inputs": {"ckpt_name": checkpoint},
        },
        "5": {
            "class_type": "EmptyLatentImage",
            "inputs": {"width": width, "height": height, "batch_size": 1},
        },
        "6": {
            "class_type": "CLIPTextEncode",
            "inputs": {"text": positive, "clip": ["4", 1]},
        },
        "7": {
            "class_type": "CLIPTextEncode",
            "inputs": {"text": negative, "clip": ["4", 1]},
        },
        "8": {
            "class_type": "KSampler",
            "inputs": {
                "model": ["4", 0],
                "positive": ["6", 0],
                "negative": ["7", 0],
                "latent_image": ["5", 0],
                "seed": seed,
                "steps": steps,
                "cfg": cfg,
                "sampler_name": sampler,
                "scheduler": "normal",
                "denoise": 1.0,
            },
        },
        "9": {
            "class_type": "VAEDecode",
            "inputs": {"samples": ["8", 0], "vae": ["4", 2]},
        },
        "10": {
            "class_type": "SaveImage",
            "inputs": {"images": ["9", 0], "filename_prefix": "pixelstudio"},
        },
    }


# ── ComfyUI HTTP client ───────────────────────────────────────────────────────

class ComfyClient:
    def __init__(self):
        self.base_url = settings.comfy_base_url
        self.client_id = str(uuid.uuid4())

    async def health_check(self) -> bool:
        try:
            async with httpx.AsyncClient(timeout=3.0) as client:
                r = await client.get(f"{self.base_url}/system_stats")
                return r.status_code == 200
        except Exception:
            return False

    async def queue_prompt(self, workflow: dict) -> str:
        """Submit a workflow; return the ComfyUI prompt_id."""
        payload = {"prompt": workflow, "client_id": self.client_id}
        async with httpx.AsyncClient(timeout=30.0) as client:
            r = await client.post(f"{self.base_url}/prompt", json=payload)
            r.raise_for_status()
            return r.json()["prompt_id"]

    async def get_history(self, prompt_id: str) -> dict:
        async with httpx.AsyncClient(timeout=10.0) as client:
            r = await client.get(f"{self.base_url}/history/{prompt_id}")
            r.raise_for_status()
            return r.json()

    async def get_output_filename(self, prompt_id: str) -> str | None:
        """Poll history until the job finishes; return the saved filename."""
        for _ in range(300):  # up to ~5 minutes
            history = await self.get_history(prompt_id)
            if prompt_id in history:
                outputs = history[prompt_id].get("outputs", {})
                for node_output in outputs.values():
                    images = node_output.get("images", [])
                    if images:
                        return images[0]["filename"]
            await asyncio.sleep(1)
        return None

    async def stream_progress(
        self,
        prompt_id: str,
        on_progress: Callable[[int], None],
    ) -> str | None:
        """
        Connect to ComfyUI's WebSocket and emit progress 0-100 via callback.
        Returns the output filename when done, or None on timeout/error.
        """
        ws_url = f"{settings.comfy_ws_url}?clientId={self.client_id}"
        output_filename: str | None = None

        try:
            async with websockets.connect(ws_url) as ws:
                async for raw in ws:
                    msg = json.loads(raw) if isinstance(raw, str) else {}
                    msg_type = msg.get("type")

                    if msg_type == "progress":
                        data = msg.get("data", {})
                        step = data.get("value", 0)
                        total = data.get("max", 1)
                        pct = int(step / total * 95)
                        await on_progress(pct)

                    elif msg_type == "executed":
                        data = msg.get("data", {})
                        if data.get("prompt_id") == prompt_id:
                            output = data.get("output", {})
                            images = output.get("images", [])
                            if images:
                                output_filename = images[0]["filename"]
                            on_progress(100)
                            break

                    elif msg_type == "execution_error":
                        data = msg.get("data", {})
                        if data.get("prompt_id") == prompt_id:
                            raise RuntimeError(data.get("exception_message", "ComfyUI error"))

        except Exception as exc:
            raise RuntimeError(f"ComfyUI WebSocket error: {exc}") from exc

        return output_filename


# Singleton
comfy_client = ComfyClient()
